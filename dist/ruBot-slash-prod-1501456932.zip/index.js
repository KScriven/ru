'use strict';

exports.handler = function(req, res) {
    
    checkToken(req, res, function(err, reply) {
        if (err) {
            return res.json(err);
        } else if (res === "") {
            res.json("Please enter some text to reverse!");
        } else {
            var reverse = req.text.value.split('').reverse().join('');
            res.json(reverse);
        }
    });
    //Echo back the text the user typed in
    //context.succeed('You sent: ' + event.text);
}



//
//exports.handler = function(event, context) {
//    //Echo back the text the user typed in
//    context.succeed('You sent: ' + event.text);
//};