'use strict';

const request = require('request');
const slacktoken = process.env.SLACK_VERIFICATION_TOKEN;


exports.handler = {
    reverse: reverse

};


function checkToken(req, res, cb) {

  var key = slacktoken;

  if (key === slacktoken) {
    return cb ("", "Valid token received.");
  } else {
    return cb("Error: Sorry, the token key is invalid.");
  }
}
 
function reverse(req, res) {

  checkToken(req, res, function(err, reply) {
    if (err) {
        return res.json(err); 
    } else if (req.text === "") {
        res.json("Please enter some text to reverse!");
    } else {
        console.log(reply);
        var gnirts = req.text.split('').reverse().join('');
        res.json(gnirts);
    }
  });
}


//
//exports.handler = function(event, context) {
//    //Echo back the text the user typed in
//    context.succeed('You sent: ' + event.text);
//};