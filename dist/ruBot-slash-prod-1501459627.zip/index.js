'use strict';

const httpstatus = require('./lib/httpstatus');
//const request = require('request');
const express = require('express');
const bodyParser = require('body-parser');
const slacktoken = process.env.SLACK_VERIFICATION_TOKEN;

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set('port', (process.env.PORT || 9001));


/* *******************************
/* HTTP Status Cats Slash Command
/* ***************************** */


app.post('/', (req, res) => {
  handleQueries(req.body, res);
});

function handleQueries(q, res) {
  if(q.token !== process.env.SLACK_VERIFICATION_TOKEN) {
    // the request is NOT coming from Slack!
    return;
  }
  if (q.text) {
    let code = q.text;

    if(! /^\d+$/.test(code)) { // not a digit
      res.send('Enter a status code like 200 😒');
      return;
    }

    let status = httpstatus[code];
    if(!status) {
      res.send('Bummer, ' + code + ' is not an official HTTP status code 🙃');
      return;
    }

    let image = 'https://http.cat/' + code;
    let data = {
      response_type: 'in_channel', // public to the channel
      text: code + ': ' + status,
      attachments:[
      {
        image_url: image
      }
    ]};
    res.json(data);
  } else {
    let data = {
      response_type: 'ephemeral', // private message
      text: 'How to use /httpstatus command:',
      attachments:[
      {
        text: 'Type a status code after the command, e.g. `/httpstatus 404`',
      }
    ]};
    res.json(data);
  }
}

exports.handler = function(event, context, callback) {
    if (slacktoken) {
            handleQueries(event, context); 
            context.succeed();
    } else {
            callback('An error has occured');
        }
    };

